package com.hruthikesh.ime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImeApplicationTests {

    @Test
    void contextLoads() {
    }

}


