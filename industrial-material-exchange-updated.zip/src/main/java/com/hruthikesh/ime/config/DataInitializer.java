package com.hruthikesh.ime.config;

import com.hruthikesh.ime.entity.Category;
import com.hruthikesh.ime.entity.Demand;
import com.hruthikesh.ime.entity.Organisation;
import com.hruthikesh.ime.entity.Supply;
import com.hruthikesh.ime.entity.enums.Status;
import com.hruthikesh.ime.entity.enums.Unit;
import com.hruthikesh.ime.repository.CategoryRepository;
import com.hruthikesh.ime.repository.DemandRepository;
import com.hruthikesh.ime.repository.OrganisationRepository;
import com.hruthikesh.ime.repository.SupplyRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.*;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final CategoryRepository categoryRepository;
    private final OrganisationRepository organisationRepository;
    private final SupplyRepository supplyRepository;
    private final DemandRepository demandRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public DataInitializer(CategoryRepository categoryRepository,
                           OrganisationRepository organisationRepository,
                           SupplyRepository supplyRepository,
                           DemandRepository demandRepository,
                           PasswordEncoder passwordEncoder) {
        this.categoryRepository = categoryRepository;
        this.organisationRepository = organisationRepository;
        this.supplyRepository = supplyRepository;
        this.demandRepository = demandRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        log.info("Checking and seeding initial data according to README specifications...");
        Map<String, Category> categories = seedCategories();
        Map<String, Organisation> organisations = seedOrganisations();
        seedSuppliesAndDemands(categories, organisations);
        log.info("Initial data setup complete.");
    }

    private Map<String, Category> seedCategories() {
        List<String> categoryNames = List.of(
                "Raw Metal",
                "Timber",
                "Textile",
                "Chemical",
                "Agricultural",
                "Plastic",
                "Electronics"
        );

        Map<String, Category> map = new HashMap<>();
        for (String name : categoryNames) {
            Category cat = categoryRepository.findByName(name).orElseGet(() ->
                    categoryRepository.save(Category.builder().name(name).build())
            );
            map.put(name, cat);
        }
        return map;
    }

    private Map<String, Organisation> seedOrganisations() {
        String encodedPassword = passwordEncoder.encode("password");
        Map<String, Organisation> orgMap = new HashMap<>();

        record OrgSeed(String contact, String name, String location, double lat, double lng) {}

        List<OrgSeed> seeds = List.of(
                new OrgSeed("9845000001", "Karnataka Steel Fab", "Industrial Area, Tamaka, Kolar, KA", 13.1367, 78.1291),
                new OrgSeed("9845000002", "Hoskote Timber Mills", "Hebbal Industrial Estate, Mysore, KA", 12.2958, 76.6394),
                new OrgSeed("9845000003", "Vellore Tannery & Textiles", "Industrial Development Area, Anantapur, AP", 14.6819, 77.6006),
                new OrgSeed("9845000004", "Bengaluru Precision Casting", "Peenya Industrial Area, Bengaluru, KA", 13.0285, 77.5197),
                new OrgSeed("9845000005", "Hubli Alloy Foundry", "Gokul Road Industrial Estate, Hubli, KA", 15.3647, 75.1240),
                new OrgSeed("9845000006", "Belgaum Hydraulic Parts", "Udyambag, Belgaum, KA", 15.8497, 74.4977),
                new OrgSeed("9845000007", "Mangalore Petrochem Refiners", "Baikampady Industrial Area, Mangalore, KA", 12.9360, 74.8235),
                new OrgSeed("9845000008", "Bellary Iron & Pellets", "Toranagallu, Bellary, KA", 15.1394, 76.9214),
                new OrgSeed("9845000009", "Tumkur BioAgri Organics", "Vasanthanarasapura, Tumkur, KA", 13.3409, 77.1010),
                new OrgSeed("9845000010", "Davanagere Cotton Ginners", "Industrial Estate, Davanagere, KA", 14.4644, 75.9218),
                new OrgSeed("9845000011", "Shimoga Auto Forgings", "Machenahalli, Shimoga, KA", 13.9299, 75.5681),
                new OrgSeed("9845000012", "Hassan Plastic Moulds", "Growth Centre, Hassan, KA", 13.0072, 76.0963),
                new OrgSeed("9845000013", "Udupi CNC Components", "Manipal Ind Area, Udupi, KA", 13.3409, 74.7421),
                new OrgSeed("9845000014", "Bidar Agro Commodities", "Kolhar Ind Area, Bidar, KA", 17.9104, 77.5199),
                new OrgSeed("9845000015", "Raichur Solvent Extraction", "Chicksugur, Raichur, KA", 16.2076, 77.3463),
                new OrgSeed("9845000016", "Bagalkot Cement Composites", "Navanagar, Bagalkot, KA", 16.1875, 75.6980),
                new OrgSeed("9845000017", "Kalaburagi Pulses Processing", "Kapnoor Ind Area, Kalaburagi, KA", 17.3297, 76.8343),
                new OrgSeed("9845000018", "Gadag BioFuels & Biomass", "Narasapur, Gadag, KA", 15.4290, 75.6268),
                new OrgSeed("9845000019", "Mandya Sugarcane Biowaste", "Tubinakere, Mandya, KA", 12.5218, 76.8951),
                new OrgSeed("9845000020", "Chikkamagaluru Heavy Timbers", "Industrial Estate, Chikkamagaluru, KA", 13.3153, 75.7754),
                new OrgSeed("9845000021", "Chennai Auto Stampings", "Ambattur Industrial Estate, Chennai, TN", 13.0983, 80.1623),
                new OrgSeed("9845000022", "Coimbatore Textile Mills", "Peelamedu, Coimbatore, TN", 11.0168, 76.9558),
                new OrgSeed("9845000023", "Salem Special Steel Works", "Omalur Road, Salem, TN", 11.6643, 78.1460),
                new OrgSeed("9845000024", "Madurai Rubber & Polymers", "Kappalur Industrial Area, Madurai, TN", 9.9252, 78.1198),
                new OrgSeed("9845000025", "Tiruppur Export Spinners", "Angeripalayam, Tiruppur, TN", 11.1085, 77.3411),
                new OrgSeed("9845000026", "Erode Agro Chemicals", "Perundurai SIPCOT, Erode, TN", 11.3410, 77.7172),
                new OrgSeed("9845000027", "Tiruchirappalli Boiler Parts", "Thuvakudi, Trichy, TN", 10.7905, 78.7047),
                new OrgSeed("9845000028", "Ranipet Leather Tannery", "SIPCOT Industrial Complex, Ranipet, TN", 12.9272, 79.3330),
                new OrgSeed("9845000029", "Hosur Electronics Assembly", "SIPCOT Phase 1, Hosur, TN", 12.7409, 77.8253),
                new OrgSeed("9845000030", "Tuticorin Salt & Chemicals", "SIPCOT, Tuticorin, TN", 8.7642, 78.1348),
                new OrgSeed("9845000031", "Dindigul Lock & Hardware", "Nagal Nagar, Dindigul, TN", 10.3673, 77.9803),
                new OrgSeed("9845000032", "Karur Paper & Textiles", "Manmangalam, Karur, TN", 10.9601, 78.0766),
                new OrgSeed("9845000033", "Kanchipuram Silk & Fabrics", "Pillaiyarpalayam, Kanchipuram, TN", 12.8342, 79.7036),
                new OrgSeed("9845000034", "Cuddalore Fine Chemicals", "Semmankuppam, Cuddalore, TN", 11.7480, 79.7714),
                new OrgSeed("9845000035", "Thanjavur Agro Mills", "Nanjikottai, Thanjavur, TN", 10.7870, 79.1378),
                new OrgSeed("9845000036", "Visakhapatnam Heavy Forgings", "Autonagar, Visakhapatnam, AP", 17.6868, 83.2185),
                new OrgSeed("9845000037", "Vijayawada Polymer Pipes", "Enikepadu, Vijayawada, AP", 16.5062, 80.6480),
                new OrgSeed("9845000038", "Guntur Cotton Pressing", "Nallapadu, Guntur, AP", 16.3067, 80.4365),
                new OrgSeed("9845000039", "Nellore Aqua Feeds", "Venkatachalam, Nellore, AP", 14.4426, 79.9865),
                new OrgSeed("9845000040", "Kurnool Minerals & Barite", "Dhone Industrial Area, Kurnool, AP", 15.8281, 78.0373),
                new OrgSeed("9845000041", "Tirupati Copper Conductors", "Renigunta, Tirupati, AP", 13.6288, 79.4192),
                new OrgSeed("9845000042", "Rajahmundry Paper Board", "Dowleswaram, Rajahmundry, AP", 17.0005, 81.8040),
                new OrgSeed("9845000043", "Kakinada Fertilizer Derivatives", "Vakalapudi, Kakinada, AP", 16.9891, 82.2475),
                new OrgSeed("9845000044", "Kadapa Barytes Pulverizing", "Mangampet, Kadapa, AP", 14.4673, 78.8242),
                new OrgSeed("9845000045", "Chittoor Pulp & Fruit Wastes", "GD Nellore, Chittoor, AP", 13.2172, 79.1003),
                new OrgSeed("9845000046", "Srikakulam Jute Processors", "Pydibhimavaram, Srikakulam, AP", 18.2949, 83.8938),
                new OrgSeed("9845000047", "Ongole Granite Slurry", "Chimakurthy, Ongole, AP", 15.5057, 80.0499),
                new OrgSeed("9845000048", "Eluru Bio Organic Manure", "Sanivarapupeta, Eluru, AP", 16.7107, 81.0952),
                new OrgSeed("9845000049", "Machilipatnam Brass Foundries", "Rustumbada, Machilipatnam, AP", 16.1875, 81.1389),
                new OrgSeed("9845000050", "Anantapur Solar Wastes", "Rapthadu, Anantapur, AP", 14.6150, 77.5850)
        );

        for (OrgSeed seed : seeds) {
            Organisation org = organisationRepository.findByContactNumber(seed.contact).orElseGet(() ->
                    organisationRepository.save(Organisation.builder()
                            .contactNumber(seed.contact)
                            .name(seed.name)
                            .password(encodedPassword)
                            .address(seed.location)
                            .latitude(seed.lat)
                            .longitude(seed.lng)
                            .build())
            );
            orgMap.put(seed.contact, org);
        }
        return orgMap;
    }

    private void seedSuppliesAndDemands(Map<String, Category> categories, Map<String, Organisation> organisations) {
        if (supplyRepository.count() > 0 && demandRepository.count() > 0) {
            return;
        }

        Organisation org1 = organisations.get("9845000001"); // Karnataka Steel Fab
        Organisation org2 = organisations.get("9845000002"); // Hoskote Timber Mills
        Organisation org3 = organisations.get("9845000003"); // Vellore Tannery & Textiles
        Organisation org21 = organisations.get("9845000021"); // Chennai Auto Stampings
        Organisation org22 = organisations.get("9845000022"); // Coimbatore Textile Mills
        Organisation org23 = organisations.get("9845000023"); // Salem Special Steel Works
        Organisation org9 = organisations.get("9845000009"); // Tumkur BioAgri Organics
        Organisation org12 = organisations.get("9845000012"); // Hassan Plastic Moulds
        Organisation org29 = organisations.get("9845000029"); // Hosur Electronics Assembly

        Category rawMetal = categories.get("Raw Metal");
        Category timber = categories.get("Timber");
        Category textile = categories.get("Textile");
        Category chemical = categories.get("Chemical");
        Category agricultural = categories.get("Agricultural");
        Category plastic = categories.get("Plastic");
        Category electronics = categories.get("Electronics");

        // Seed Supplies
        if (supplyRepository.count() == 0) {
            List<Supply> supplies = List.of(
                    Supply.builder()
                            .name("Scrap Carbon Steel Plates")
                            .category(rawMetal)
                            .organisation(org1)
                            .description("High-grade 10-16mm heavy scrap steel offcuts from industrial fabrication.")
                            .pricePerUnit(new BigDecimal("38.00"))
                            .quantity(new BigDecimal("15000"))
                            .unit(Unit.KG)
                            .maxDistance(300.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("Structural Steel Beam Cutoffs")
                            .category(rawMetal)
                            .organisation(org1)
                            .description("Mild steel I-beam cutoffs suitable for rerolling and smelting.")
                            .pricePerUnit(new BigDecimal("42.00"))
                            .quantity(new BigDecimal("8000"))
                            .unit(Unit.KG)
                            .maxDistance(250.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("Reclaimed Pine Timber Slats")
                            .category(timber)
                            .organisation(org2)
                            .description("Surplus seasoned pine timber slats from construction batch.")
                            .pricePerUnit(new BigDecimal("16.50"))
                            .quantity(new BigDecimal("12000"))
                            .unit(Unit.KG)
                            .maxDistance(300.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("Hardwood Offcuts & Pallets")
                            .category(timber)
                            .organisation(org2)
                            .description("High-strength dense hardwood scraps and timber pallets.")
                            .pricePerUnit(new BigDecimal("15.00"))
                            .quantity(new BigDecimal("9000"))
                            .unit(Unit.KG)
                            .maxDistance(250.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("Processed Leather Scraps")
                            .category(textile)
                            .organisation(org3)
                            .description("Vegetable tanned leather trimmings suitable for bonded leather.")
                            .pricePerUnit(new BigDecimal("28.00"))
                            .quantity(new BigDecimal("6000"))
                            .unit(Unit.KG)
                            .maxDistance(250.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("CRCA Sheet Punching Scrap")
                            .category(rawMetal)
                            .organisation(org21)
                            .description("Clean cold-rolled close annealed steel sheets from stamping dies.")
                            .pricePerUnit(new BigDecimal("36.00"))
                            .quantity(new BigDecimal("18000"))
                            .unit(Unit.KG)
                            .maxDistance(300.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("Yarn Waste & Comber Noil")
                            .category(textile)
                            .organisation(org22)
                            .description("High fiber 100% combed cotton yarn waste from spinning.")
                            .pricePerUnit(new BigDecimal("32.00"))
                            .quantity(new BigDecimal("7000"))
                            .unit(Unit.KG)
                            .maxDistance(300.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("Stainless Steel SS304 Turnings")
                            .category(rawMetal)
                            .organisation(org23)
                            .description("Clean SS304 lathe turnings and scrap chips.")
                            .pricePerUnit(new BigDecimal("95.00"))
                            .quantity(new BigDecimal("4500"))
                            .unit(Unit.KG)
                            .maxDistance(400.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("Coir Pith & Shell Charcoal")
                            .category(agricultural)
                            .organisation(org9)
                            .description("Organic coir pith and activated coconut shell charcoal briquettes.")
                            .pricePerUnit(new BigDecimal("12.00"))
                            .quantity(new BigDecimal("25000"))
                            .unit(Unit.KG)
                            .maxDistance(400.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("Reground HDPE Granules")
                            .category(plastic)
                            .organisation(org12)
                            .description("Washed reground high density polyethylene granules.")
                            .pricePerUnit(new BigDecimal("55.00"))
                            .quantity(new BigDecimal("10000"))
                            .unit(Unit.KG)
                            .maxDistance(300.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Supply.builder()
                            .name("Defective PCB Boards for E-waste")
                            .category(electronics)
                            .organisation(org29)
                            .description("Bare and populated printed circuit boards for precious metal extraction.")
                            .pricePerUnit(new BigDecimal("85.00"))
                            .quantity(new BigDecimal("2000"))
                            .unit(Unit.KG)
                            .maxDistance(500.0)
                            .status(Status.ACTIVE)
                            .build()
            );
            supplyRepository.saveAll(supplies);
        }

        // Seed Demands
        if (demandRepository.count() == 0) {
            List<Demand> demands = List.of(
                    Demand.builder()
                            .name("Heavy Industrial Timber Pallets")
                            .category(timber)
                            .organisation(org1)
                            .description("Sturdy hardwood or pine pallets for machinery handling and transport.")
                            .pricePerUnit(new BigDecimal("18.00"))
                            .quantity(new BigDecimal("5000"))
                            .unit(Unit.KG)
                            .maxDistance(350.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Demand.builder()
                            .name("Coolant & Cutting Oil Surplus")
                            .category(chemical)
                            .organisation(org1)
                            .description("Recyclable semi-synthetic soluble cutting oil and machine coolant.")
                            .pricePerUnit(new BigDecimal("60.00"))
                            .quantity(new BigDecimal("2000"))
                            .unit(Unit.LITRE)
                            .maxDistance(200.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Demand.builder()
                            .name("Steel Strapping Wire Offcuts")
                            .category(rawMetal)
                            .organisation(org2)
                            .description("High tensile steel wire scraps for bundle packaging.")
                            .pricePerUnit(new BigDecimal("45.00"))
                            .quantity(new BigDecimal("3000"))
                            .unit(Unit.KG)
                            .maxDistance(300.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Demand.builder()
                            .name("Industrial Salt & Chemicals")
                            .category(chemical)
                            .organisation(org3)
                            .description("Surplus technical grade industrial salt for processing.")
                            .pricePerUnit(new BigDecimal("14.00"))
                            .quantity(new BigDecimal("10000"))
                            .unit(Unit.KG)
                            .maxDistance(300.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Demand.builder()
                            .name("Scrap Carbon Steel Plates")
                            .category(rawMetal)
                            .organisation(org23)
                            .description("Heavy gauge scrap steel plates for induction melting.")
                            .pricePerUnit(new BigDecimal("40.00"))
                            .quantity(new BigDecimal("20000"))
                            .unit(Unit.KG)
                            .maxDistance(350.0)
                            .status(Status.ACTIVE)
                            .build(),
                    Demand.builder()
                            .name("Textile Sizing Polymers")
                            .category(chemical)
                            .organisation(org22)
                            .description("PVA and starch blend polymers for yarn sizing.")
                            .pricePerUnit(new BigDecimal("50.00"))
                            .quantity(new BigDecimal("2500"))
                            .unit(Unit.KG)
                            .maxDistance(200.0)
                            .status(Status.ACTIVE)
                            .build()
            );
            demandRepository.saveAll(demands);
        }
    }
}
