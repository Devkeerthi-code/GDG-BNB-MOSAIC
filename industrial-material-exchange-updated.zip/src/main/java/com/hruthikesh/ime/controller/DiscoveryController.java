package com.hruthikesh.ime.controller;

import com.hruthikesh.ime.dto.MatchResponse;
import com.hruthikesh.ime.entity.Supply;
import com.hruthikesh.ime.service.MatchingAlgorithmService;
import com.hruthikesh.ime.service.SupplyService;
import com.hruthikesh.ime.entity.Demand;
import com.hruthikesh.ime.service.DemandService;
import com.hruthikesh.ime.repository.OrganisationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/discover")
public class DiscoveryController {

    private final SupplyService supplyService;
    private final DemandService demandService;
    private final MatchingAlgorithmService matchingAlgorithmService;
    private final OrganisationRepository organisationRepository;

    @Autowired
    public DiscoveryController(SupplyService supplyService, DemandService demandService,
                               MatchingAlgorithmService matchingAlgorithmService,
                               OrganisationRepository organisationRepository) {
        this.supplyService = supplyService;
        this.demandService = demandService;
        this.matchingAlgorithmService = matchingAlgorithmService;
        this.organisationRepository = organisationRepository;
    }

    @GetMapping({"", "/"})
    public String discoverMarketplace(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Double centerLat = 12.9716;
        Double centerLng = 77.5946;
        String orgName = "Karnataka";

        Long userOrgId = null;
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
            var orgOpt = organisationRepository.findByContactNumber(auth.getName());
            if (orgOpt.isPresent()) {
                var userOrg = orgOpt.get();
                userOrgId = userOrg.getId();
                centerLat = userOrg.getLatitude();
                centerLng = userOrg.getLongitude();
                orgName = userOrg.getName();
            }
        }

        List<Supply> allSupplies = supplyService.getAllActiveSupplies();
        List<MatchResponse> matches = new ArrayList<>();

        for (Supply s : allSupplies) {
            if (userOrgId != null && s.getOrganisation().getId().equals(userOrgId)) {
                continue;
            }

            double distance = 0.0;
            if (s.getOrganisation().getLatitude() != null && s.getOrganisation().getLongitude() != null) {
                distance = calculateHaversine(centerLat, centerLng, s.getOrganisation().getLatitude(), s.getOrganisation().getLongitude());
            }

            matches.add(MatchResponse.builder()
                    .id(s.getId())
                    .name(s.getName())
                    .description(s.getDescription())
                    .orgName(s.getOrganisation().getName())
                    .orgContact(s.getOrganisation().getContactNumber())
                    .pricePerUnit(s.getPricePerUnit())
                    .quantity(s.getQuantity())
                    .unit(s.getUnit().name())
                    .distanceKm(Math.round(distance * 100.0) / 100.0)
                    .latitude(s.getOrganisation().getLatitude())
                    .longitude(s.getOrganisation().getLongitude())
                    .totalScore(100.0)
                    .build());
        }

        model.addAttribute("sourceItem", null);
        model.addAttribute("sourceType", "All Supplies");
        model.addAttribute("matches", matches);
        model.addAttribute("centerLat", centerLat);
        model.addAttribute("centerLng", centerLng);
        model.addAttribute("centerName", orgName);

        return "discover";
    }

    @GetMapping("/supply/{supplyId}")
    public String discoverDemandsForSupply(@PathVariable Long supplyId, Model model) {
        Supply supply = supplyService.getSupplyById(supplyId);
        List<MatchResponse> matches = matchingAlgorithmService.discoverMatchesForSupply(supply);

        model.addAttribute("sourceItem", supply);
        model.addAttribute("sourceType", "Supply");
        model.addAttribute("matches", matches);
        model.addAttribute("centerLat", supply.getOrganisation().getLatitude());
        model.addAttribute("centerLng", supply.getOrganisation().getLongitude());
        model.addAttribute("centerName", supply.getOrganisation().getName());

        return "discover";
    }

    @GetMapping("/demand/{demandId}")
    public String discoverSuppliesForDemand(@PathVariable Long demandId, Model model) {
        Demand demand = demandService.getDemandById(demandId);
        List<MatchResponse> matches = matchingAlgorithmService.discoverMatchesForDemand(demand);

        model.addAttribute("sourceItem", demand);
        model.addAttribute("sourceType", "Demand");
        model.addAttribute("matches", matches);
        model.addAttribute("centerLat", demand.getOrganisation().getLatitude());
        model.addAttribute("centerLng", demand.getOrganisation().getLongitude());
        model.addAttribute("centerName", demand.getOrganisation().getName());

        return "discover";
    }

    private double calculateHaversine(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371;
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
}
